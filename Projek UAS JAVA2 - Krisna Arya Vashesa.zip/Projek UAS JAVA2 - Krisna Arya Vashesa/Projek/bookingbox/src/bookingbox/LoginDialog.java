/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookingbox;
import bookingbox.koneksi;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.Frame;
import java.sql.Connection;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author krisna
 */
public class LoginDialog extends JDialog {
    private boolean loginBerhasil = false;
    private String namaUser;

    public LoginDialog(Frame parent) {
        super(parent, "Login", true);
        initComponents();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        JTextField tfEmail = new JTextField(15);
        JPasswordField pfPassword = new JPasswordField(15);
        JButton btnLogin = new JButton("Login");

        btnLogin.addActionListener(e -> {
            String email = tfEmail.getText();
            String password = new String(pfPassword.getPassword());

            try (Connection conn = koneksi.getConnection()) {
                String sql = "SELECT * FROM USERS WHERE EMAIL=? AND PASSWORD=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, email);
                ps.setString(2, password);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    loginBerhasil = true;
                    namaUser = rs.getString("NAMA");
                    dispose(); // tutup dialog
                } else {
                    JOptionPane.showMessageDialog(this, "Login gagal, periksa email dan password.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + ex.getMessage());
            }
        });

        setLayout(new GridLayout(3, 2));
        add(new JLabel("Email:"));
        add(tfEmail);
        add(new JLabel("Password:"));
        add(pfPassword);
        add(btnLogin);

        pack();
    }

    public boolean isLoginBerhasil() {
        return loginBerhasil;
    }

    public String getNamaUser() {
        return namaUser;
    }
}
