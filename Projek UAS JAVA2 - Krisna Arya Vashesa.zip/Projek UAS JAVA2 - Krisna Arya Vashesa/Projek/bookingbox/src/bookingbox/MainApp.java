/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookingbox;

/**
 *
 * @author krisna
 */
public class MainApp {
    private static boolean isLoggedIn = false;

    public static void setLoginStatus(boolean status) {
        isLoggedIn = status;
    }

    public static boolean getLoginStatus() {
        return isLoggedIn;
    }
}