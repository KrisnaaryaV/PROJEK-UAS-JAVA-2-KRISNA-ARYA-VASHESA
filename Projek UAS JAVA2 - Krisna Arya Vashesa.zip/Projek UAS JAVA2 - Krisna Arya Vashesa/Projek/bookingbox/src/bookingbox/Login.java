package bookingbox;

import bookingbox.koneksi;
import java.sql.*;
import javax.swing.*;

public class Login extends JFrame {
    private JTextField jTextEmail;
    private JPasswordField jPassword;
    private JButton jButtonLogin;

    public Login() {
        setTitle("Login Pengguna");
        setSize(350, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel labelEmail = new JLabel("Email:");
        labelEmail.setBounds(30, 30, 80, 25);
        add(labelEmail);

        jTextEmail = new JTextField();
        jTextEmail.setBounds(120, 30, 170, 25);
        add(jTextEmail);

        JLabel labelPassword = new JLabel("Password:");
        labelPassword.setBounds(30, 65, 80, 25);
        add(labelPassword);

        jPassword = new JPasswordField();
        jPassword.setBounds(120, 65, 170, 25);
        add(jPassword);

        jButtonLogin = new JButton("Login");
        jButtonLogin.setBounds(120, 100, 100, 30);
        add(jButtonLogin);

        jButtonLogin.addActionListener(e -> loginAction());

        setVisible(true);
    }

    private void loginAction() {
        String email = jTextEmail.getText();
        String password = new String(jPassword.getPassword());

        try (Connection conn = koneksi.getConnection()) {
            String sql = "SELECT * FROM USERS WHERE EMAIL = ? AND PASSWORD = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String nama = rs.getString("NAMA");
                JOptionPane.showMessageDialog(this, "Selamat datang, " + nama);

                // Buka halaman pemesanan
                pemesanan Pemesanan = new pemesanan(nama);
                Pemesanan.setVisible(true);
                dispose(); // Tutup form login

            } else {
                JOptionPane.showMessageDialog(this, "Email atau password salah.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Kesalahan koneksi: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Login());
    }
}
